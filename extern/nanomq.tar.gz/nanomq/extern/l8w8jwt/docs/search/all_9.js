var searchData=
[
  ['nbf_0',['nbf',['../structl8w8jwt__encoding__params.html#a8b8679a552ccdcaab45582bd5247ae41',1,'l8w8jwt_encoding_params']]],
  ['nbf_5ftolerance_5fseconds_1',['nbf_tolerance_seconds',['../structl8w8jwt__decoding__params.html#aa06c18153fe45feeb19941d2c9882d80',1,'l8w8jwt_decoding_params']]]
];
