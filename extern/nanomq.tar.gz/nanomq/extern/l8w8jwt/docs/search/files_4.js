var searchData=
[
  ['encode_2eh_0',['encode.h',['../encode_8h.html',1,'']]]
];
